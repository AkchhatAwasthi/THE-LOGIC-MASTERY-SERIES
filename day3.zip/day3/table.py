num=int(input("Enter the number: "))
Range=int(input("enter the range: "))
for i in range(1,Range+1):
    print(f"{num} x {i} = {num*i}")