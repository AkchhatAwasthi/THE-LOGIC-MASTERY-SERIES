s=input("Enter your string: ").lower()# my name is amish
v_count=0
c_count=0
s_count=0
a='aeiou'
b=['a','e','i','o','u']
for i in s:
    if i in a:
        v_count+=1
    elif i == " ":
        s_count+=1
    else:
        c_count+=1
print("vowel",v_count)
print("non-vowel",c_count)
print("space",s_count)

