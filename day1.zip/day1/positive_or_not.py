num1=int(input("enter your number: "))
if(num1>0):
    print("positive")
elif(num1==0):
    print("number is zero")
else:
    print("number is negative")