c=input("Enter your char: ").lower()
if c in "aeiou" :
    print("it is a vowel")
else:
    print("not a vowel")