num1=int(input("enter your number: "))
if(num1<2):
    print("not prime")
else:
    flag=True
    for i in range(2,num1-1):
        if num1%i==0:
            flag=False
if flag :
    print("It is a prime number")
else:
    print("not a prime number")