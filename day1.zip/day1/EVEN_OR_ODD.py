num1=int(input("enter your number"))
if num1%2==0:
    print("even")
else:
    print("odd")