# racecar racecar
stri=input("Enter your string: ")
if(stri==stri[::-1]):
    print("plaindrome")
else:
    print("not a palindrome")
