# 0 1 1 2  3 5 8 13
num1=int(input("Enter digit")) #8
a,b=0,1
print(a,b,end=" ")
for i in range(2,num1):# 2 3 4 5 6 7
    sum=a+b
    print(sum,end=" ")
    a=b
    b=sum 

