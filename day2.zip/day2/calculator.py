num1=int(input("Enter your number"))
num2=int(input("Enter your number"))
sign=input("enter the operator")
if (sign== '+'):
    print("addition: ",num1+num2)
elif(sign=='-'):
    print("sub: ",num1-num2)
elif(sign=='*'):
    print("mul: ",num1*num2)
elif(sign=='//'):
    print("div: ",num1//num2)
elif(sign=='%'):
    print("mod: ",num1%num2)